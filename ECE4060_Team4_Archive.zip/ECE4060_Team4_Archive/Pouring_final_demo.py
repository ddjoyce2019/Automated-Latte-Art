import pigpio
from gpiozero import OutputDevice
from gpiozero import PWMOutputDevice
from time import sleep
import threading

pi1 = pigpio.pi()
pi1.set_mode(18, pigpio.OUTPUT) # servo1
pi1.set_mode(16, pigpio.OUTPUT) # servo2

act1 = OutputDevice(17) #turns on and off 0.31 in/sec
pw1 =PWMOutputDevice(13, frequency = 80) #controls direction 
act2 = OutputDevice(27) #turns on and off 0.41379 in/sec
pw2 =PWMOutputDevice(12, frequency = 80) #controls direction  

def turn_servo(pi1, angle, gpio):
    if (angle == None): #turn servo off
        pulsewidth = 0
    else: # normalize angle to pulse width range
        OldRange = 270
        NewRange = -2000
        pulsewidth = (((angle + 135) * NewRange) / OldRange) + 2500 # min angle = -135(2500 pw) max angle = 135(500 pw)
    pi1.set_servo_pulsewidth(gpio, pulsewidth)

def move_act(act, pw, length, direction, number):
    if (direction == 'up'):
        if (number == 1): sleep_time = length / 0.32616
        elif (number == 2): sleep_time = length / 0.43054
        act.off()
        pw.on()
        sleep(sleep_time)
        pw.off()
    elif(direction == 'down'):
        if (number == 1): sleep_time = length / 0.31969
        elif (number == 2): sleep_time = length / 0.41615
        act.on()
        pw.off()
        sleep(sleep_time)
        act.off()

        # Class that holds functions to set the components to an initial position
class Initialize:
    def __init__(self, act1, act2, servo1, servo2, pw1, pw2):
        self.act1 = act1
        self.act2 = act2
        self.servo1 = servo1
        self.servo2 = servo2
        self.pw1 = pw1
        self.pw2 = pw2

    def actuator1(self):
        move_act(self.act1, self.pw1, 1, 'down', 1)

    def actuator2(self):
        move_act(self.act2, self.pw2, 1, 'down', 2)

    def serv1(self):
        turn_servo(self.servo1, 0, 18)

    def serv2(self):
        turn_servo(self.servo2, 0, 16)

# Class that holds functions to move the components in order to pour a heart design
class Heart:
    def __init__(self, act1, act2, servo1, servo2, pw1, pw2):
        self.act1 = act1
        self.act2 = act2
        self.servo1 = servo1
        self.servo2 = servo2
        self.pw1 = pw1
        self.pw2 = pw2

    def actuator1(self):
        #Out to inital pour position
        move_act(self.act1, self.pw1, .2, 'up', 1)
        #wait for canvas to pour
        sleep(15.968)
        #return to inital to prep to pour across
        move_act(self.act1, self.pw1, .2, 'down', 1)
        #wait to pour blob
        sleep(12)
        move_act(self.act1, self.pw1, 1, 'up', 1)
        #go across during blob
        move_act(self.act1, self.pw1, 1.2, 'up', 1)
        #pull across for final line
        move_act(self.act1, self.pw1, .8, 'up', 1)
        #wait after finished design
        sleep(3)
        #return to inital position
        move_act(self.act1, self.pw1, 4, 'down', 1)


    def actuator2(self):
        #raise to level to pour canvas
        move_act(self.act2, self.pw2, 3, 'up', 2)
        #wait while canvas is poured
        sleep(7.5)
        #lower to cup level for inital blob
        move_act(self.act2, self.pw2, 3, 'down', 2)
        #wait while blob is poured
        sleep(10.7)
        #raise up for final design
        move_act(self.act2,self.pw2, 1.3,'up', 2)
        #continue raising for final design
        move_act(self.act2,self.pw2, 1,'up', 2)
        #sleep while line is poured
        sleep(10.599)
        #return to inital position
        move_act(self.act2,self.pw2, 3,'down', 2)



    def serv1(self):
        #angle coffee cup for canvas pour
        turn_servo(self.servo1, -35, 18)
        sleep(0.1)
        turn_servo(self.servo1, None, 18)
        #leave while canvas is poured
        sleep(21.03)
        #rotate down for inital pour of blob
        for i in range (-35, -45, -1):
            turn_servo(self.servo1, i, 18)
            sleep(0.05)
        turn_servo(self.servo1, None, 18)
        #wait for blob
        sleep(11.25)
        #rotate back to upright position
        for i in range(-45,0,1):
            turn_servo(self.servo1,i, 18)
            sleep(.17)
        sleep(0.5)


    def serv2(self):
        #set milk cup to 0
        turn_servo(self.servo2, 0, 16)
        #wait while actuators raise to canvas height
        sleep(7.468)
        #rotate milk cup down to pour the canvas
        for i in range (0, 78, 1):
            turn_servo(self.servo2, i, 16)
            sleep(0.065)
        #wait while canvas is poured
        sleep(0.8)
        #raise milk cup back to 0
        for i in range (78, 0, -1):
            turn_servo(self.servo2, i, 16)
            sleep(0.01)
        turn_servo(self.servo2,None, 16)
        #wait while milk cup lowers to coffee cup
        sleep(11.084)
        #pouring blob
        for i in range (0, 103, 1):
            turn_servo(self.servo2, i, 16)
            sleep(0.07)
        #wait while blob is poured
        sleep(4.2)
        #return to intial position
        for i in range(103, 0, -1):
            turn_servo(self.servo2, i, 16)
            sleep(0.03)
        sleep(0.5)

# Class that holds functions to move the components in order to pour a snowman design
class Snowman:
    def __init__(self, act1, act2, servo1, servo2, pw1, pw2):
        self.act1 = act1
        self.act2 = act2
        self.servo1 = servo1
        self.servo2 = servo2
        self.pw1 = pw1
        self.pw2 = pw2

    def actuator1(self):
        #Out to inital pour position
        move_act(self.act1, self.pw1, .2, 'up', 1)
        #wait for canvas to pour
        sleep(15.968)
        #return to inital to prep to pour across
        move_act(self.act1, self.pw1, .2, 'down', 1)
        #wait to pour blob
        sleep(7)
        # move out for first pour
        move_act(self.act1, self.pw1, 2.4, 'up', 1)
        sleep(3.613)
        move_act(self.act1, self.pw1, 2.4, 'down', 1)
        sleep(4.6256)
        # move out for second pour
        move_act(self.act1, self.pw1, 2.0, 'up', 1)
        sleep(3)
        move_act(self.act1, self.pw1, 1.4, 'down', 1)
        sleep(3)
        # move out for third pour
        move_act(self.act1, self.pw1, 1.1, 'up', 1)
        sleep(3.5)
        move_act(self.act1, self.pw1, 5, 'down', 1)
        

    def actuator2(self):
        #raise to level to pour canvas
        move_act(self.act2, self.pw2, 3, 'up', 2)
        #wait while canvas is poured
        sleep(7.5)
        #lower to cup level for inital blob
        move_act(self.act2, self.pw2, 3, 'down', 2)
        sleep(7)
        # raise cup during first pour
        move_act(self.act2, self.pw2, 1.6, 'up',2)
        sleep(5.5)
        # lower cup for second pour
        move_act(self.act2, self.pw2, 0.9, 'down',2)
        sleep(12.5)
        # raise cup during second pour
        move_act(self.act2, self.pw2, 1.1, 'up',2)
        sleep(2)
        # lower cup for third pour
        move_act(self.act2, self.pw2, 0.4, 'down',2)
        sleep(12)
        # raise cup during third pour
        move_act(self.act2, self.pw2, 0.8, 'up',2)
        sleep(10)
        # move cup to initial position
        move_act(self.act2, self.pw2, 4, 'down', 2)
        

    def serv1(self):
        #angle coffee cup for canvas pour
        turn_servo(self.servo1, -35, 18)
        sleep(0.1)
        turn_servo(self.servo1, None, 18)
        #leave while canvas is poured
        sleep(21.03)
        #rotate down for inital pour of blob
        for i in range (-35, -45, -1):
            turn_servo(self.servo1, i, 18)
            sleep(0.05)
        turn_servo(self.servo1, None, 18)
        sleep(7.5)
        # rotate up for second pour
        for i in range(-45, -30, 1):
            turn_servo(self.servo1, i, 18)
            sleep(0.07)

        sleep(26)
        # rotate up for third pour
        for i in range(-30, -15, 1):
            turn_servo(self.servo1, i, 18)
            sleep(0.05)
        
        sleep(16)
        # back to start after all pours
        for i in range(-15, 0, 1):
            turn_servo(self.servo1, i, 18)
            sleep(0.05)
        


    def serv2(self):
        #set milk cup to 0
        turn_servo(self.servo2, 0, 16)
        #wait while actuators raise to canvas height
        sleep(7.468)
        #rotate milk cup down to pour the canvas
        for i in range (0, 78, 1):
            turn_servo(self.servo2, i, 16)
            sleep(0.065)
        #wait while canvas is poured
        sleep(0.8)
        #raise milk cup back to 0
        for i in range (78, 0, -1):
            turn_servo(self.servo2, i, 16)
            sleep(0.01)
    
        turn_servo(self.servo2,None, 16)
        #wait while milk cup lowers to coffee cup
        sleep(10)
        # first pour
        for i in range (0, 80, 1):
            turn_servo(self.servo2, i, 16)
            sleep(0.06)
        #wait while blob is poured
        sleep(0.5)
        # rotate cup extra to get more foam out in first pour
        for i in range (80, 100, 1):
            turn_servo(self.servo2, i, 16)
            sleep(0.1)
        #wait while blob is poured
        sleep(1)
        #return to intial position
        for i in range(100, 0, -1):
            turn_servo(self.servo2, i, 16)
            sleep(0.02)
        sleep(13.5)
        # go down for second pour
        for i in range (0, 105, 1):
            turn_servo(self.servo2, i, 16)
            sleep(0.05)
        sleep(1.8)
        # come up from second pour
        for i in range (105, 0, -1):
            turn_servo(self.servo2, i, 16)
            sleep(0.01)
        sleep(7.7)
        # go down for third pour
        for i in range(0, 110, 1):
            turn_servo(self.servo2, i, 16)
            sleep(0.05)
        sleep(0.9)
        # come up from third pour
        for i in range (110, 0, -1):
            turn_servo(self.servo2, i, 16)
            sleep(0.02)

def pour(pattern):

        initial = Initialize(act1, act2, pi1, pi1, pw1, pw2)
        act1_thread = threading.Thread(target=initial.actuator1, args=())
        act2_thread = threading.Thread(target=initial.actuator2, args=())
        servo1_thread = threading.Thread(target=initial.serv1, args=())
        servo2_thread = threading.Thread(target=initial.serv2, args=())

        # start the threads 
        act1_thread.start()
        act2_thread.start()
        servo1_thread.start()
        servo2_thread.start()


        # wait for all threads to finish
        act1_thread.join()
        act2_thread.join()
        servo1_thread.join()
        servo2_thread.join()

        if pattern==1:
            design = Heart(act1, act2, pi1, pi1, pw1, pw2)
            print('Heart')
        else:
            design = Snowman(act1, act2, pi1, pi1, pw1, pw2)
            print('Snowman')
       
        # create the design class and threads
        act1_thread = threading.Thread(target=design.actuator1, args=())
        act2_thread = threading.Thread(target=design.actuator2, args=())
        servo1_thread = threading.Thread(target=design.serv1, args=())
        servo2_thread = threading.Thread(target=design.serv2, args=())

        # start the threads
        act1_thread.start()
        act2_thread.start()
        servo1_thread.start()
        servo2_thread.start()

         # wait for all threads to finish
        act1_thread.join()
        act2_thread.join()
        servo1_thread.join()
        servo2_thread.join()
        return