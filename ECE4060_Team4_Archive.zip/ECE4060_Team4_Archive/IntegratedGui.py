import kivy
from kivy.app import App
from kivy.uix.label import Label
from kivy.uix.button import Button
from kivy.uix.widget import Widget
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.image import Image, AsyncImage
from kivy.uix.screenmanager import (ScreenManager, Screen, NoTransition)
from kivy.clock import Clock
from kivy.graphics import Canvas,Line, Color
from kivy.graphics import Color, Rectangle
import Pouring_final_demo as P

global design 

class MainMenu(Screen):
    def __init__ (self, **kwargs):
        super(MainMenu, self).__init__(**kwargs)
        
        self.main_float = FloatLayout()
       
        with self.main_float.canvas:
             Color(rgba=(0.6078, 0.72549, 1, 1))  # rgba might be better
             Rectangle(size=(1000, 1000), pos=(0,0))
             
             
        #Heart Button
        self.button1= Button(background_color=( 0.4901, 0.572549, .78431, .6),
                         pos_hint={'center_x':0.3, 'center_y':0.5}, 
                         size_hint=(0.35,0.35))
        self.label1 = Label(text='Heart',pos_hint= {'center_x':0.3, 'center_y':0.625},
                       size_hint= (0.25, 0.35), font_size='40sp')
        self.image1 = Image(source='heart.png',
                       pos_hint= {'center_x':0.3, 'center_y':0.48},
                       size_hint=( 0.365, 0.365))
        #Snowman Button
        self.button2= Button(background_color=( 0.4901, 0.572549, .78431, .6),
                         pos_hint={'center_x':0.7, 'center_y':0.5}, 
                         size_hint=(0.35,0.35))
        self.label2 = Label(text='Snowman',pos_hint= {'center_x':0.7, 'center_y':0.625},
                       size_hint= (0.25, 0.35), font_size='40sp')
        self.image2 = Image(source='snowman.png',
                       pos_hint= {'center_x':0.7, 'center_y':0.465},
                       size_hint=( 0.25, 0.25))
        
        
        #Start Button
        self.buttonS = Button( text="Start",
                          background_color=  (0.4901, 0.572549, .78431, .6),
                          pos_hint= {'center_x':0.35, 'center_y':0.2},
                          size_hint=( 0.25, 0.1),
                          font_size= '40sp')
        #Exit Button
        self.buttonE = Button(text="Exit",
                         background_color= (0.4901, 0.572549, .78431, .6),
                         pos_hint= {'center_x':0.65, 'center_y':0.2},
                         size_hint= (0.25, 0.1),
                         font_size= '40sp')
                        
        
        #Title
        self.title=Label( text= "Lazy Latte",
                     font_size= '100sp',
                     pos_hint= {'center_x':0.5, 'center_y':0.8})
                   
        
        self.add_widget(self.main_float)

        self.main_float.add_widget(self.button1)
        self.main_float.add_widget(self.label1)
        self.main_float.add_widget(self.image1)

        self.main_float.add_widget(self.button2)
        self.main_float.add_widget(self.label2)
        self.main_float.add_widget(self.image2)

              
        self.main_float.add_widget(self.buttonS)
        self.main_float.add_widget(self.buttonE)

        self.main_float.add_widget(self.title)
        
        self.buttonS.bind(on_press=self.goToLoad)
        self.button1.bind(on_press=self.change1)
        self.button2.bind(on_press=self.change2)
      
        self.buttonE.bind(on_press=self.exit)
        
    #Goes to Loading Screen
    def goToLoad(self,instance):
        #Lscreen = LoadingScreen()
        self.manager.transition = NoTransition()   
        self.manager.current = 'load'
        
    #Sets default design to 1 every time it re-enters screen 
    def on_enter(self, *args):
           global design
           design = 1
    def change1(self, instance):
           global design
           design = 1
           
    def change2(self, instance):
           global design
           design = 2
           
    
    def exit(self,instance):
          quit()      
class LoadingScreen(Screen):
    def __init__ (self, **kwargs):
        super(LoadingScreen, self).__init__(**kwargs)
        self.load_float = FloatLayout()
        with self.load_float.canvas:
             Color(rgba=(0.6078, 0.72549, 1, 1))  # rgba might be better
             Rectangle(size=(1000, 1000), pos=(0,0))
             
        self.load=Label(text= "Pouring...",
                        font_size= '40sp',
                        pos_hint= {'center_x':0.5, 'center_y':0.5})
        
        self.add_widget(self.load_float)
        self.load_float.add_widget(self.load)
        
    def on_enter(self, *args):
        Clock.schedule_once(self.start)
        
    def start(self, *args):
        global design
        
        P.pour(design)
        
        self.goToMain()
        
    def goToMain(self, *args):
         self.manager.current = 'main'  
class MyApp(App): # <- Main Class
    title = "Lazy Latte"
    def build(self):
        design = 1
        screen_manager = ScreenManager(transition = NoTransition())
        screen_manager.add_widget(MainMenu(name ="main"))
        screen_manager.add_widget(LoadingScreen(name ="load"))
        
        return screen_manager


if __name__ == "__main__":
    MyApp().run()
  
   